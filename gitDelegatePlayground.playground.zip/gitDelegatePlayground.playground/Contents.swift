//Delegate pattern using closure

import Foundation

class DelegatedPerson
{
    var didFinishAddNumbersClosure: (Int) -> Void
    init(){
        self.didFinishAddNumbersClosure = { print($0) }
    }
    
    func addTwoNumbers(a: Int, b: Int)
    {
        didFinishAddNumbersClosure(a + b)
    }
}

class Delegator
{
    var delegatee: DelegatedPerson
    init(_delegatee: DelegatedPerson) {
        delegatee = _delegatee
    }
    
    func delegateAdding(x: Int, y: Int){
        delegatee.addTwoNumbers(a: x, b: y)
    }
}
let objDelegator = Delegator(_delegatee: DelegatedPerson())

objDelegator.delegateAdding(x: 80, y: 50)

